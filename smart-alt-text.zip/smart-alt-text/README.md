# Smart Alt Text for WordPress

Automatically generate and manage image alt text using AI and bulk editing capabilities.

## Features

- 🤖 AI-powered image analysis using GPT-4 Vision
- 🔄 Bulk edit capabilities (3 images at a time)
- 📝 Customizable alt text formula
- 📊 Usage tracking and statistics
- 🔒 Secure API key storage

## Requirements

- WordPress 5.6 or higher
- PHP 7.4 or higher
- OpenAI API key with GPT-4 Vision access

## Installation

1. Download the plugin zip file
2. Go to WordPress admin panel > Plugins > Add New
3. Click "Upload Plugin" and select the downloaded zip file
4. Click "Install Now" and then "Activate"
5. Go to Settings > Smart Alt Text to configure your OpenAI API key

## Configuration

1. Enter your OpenAI API key in the plugin settings
2. Customize the character limit for alt text (default: 125)
3. Customize the alt text formula using available variables:
   - `{description}` - AI-generated image description
   - `{post_title}` - Title of the post where image appears
   - `{site_title}` - Your website name

## Usage

### Single Image Analysis
1. Go to Media Library
2. Click on an image
3. Click the "Analyze with AI" button
4. Review and save the generated alt text

### Bulk Edit
1. Go to Media Library (Grid View)
2. Select up to 3 images
3. Choose "Generate Alt Text" from the Bulk Actions dropdown
4. Click Apply

### Usage Tracking
- View usage statistics in the plugin settings
- Track where each image appears across your site
- Monitor the number of AI-generated descriptions

## Security

- API keys are encrypted before storage
- All requests are nonce-protected
- Rate limiting is implemented to prevent abuse

## Support

For support, please visit the [plugin support forum](https://wordpress.org/support/plugin/smart-alt-text/) on WordPress.org.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request. 